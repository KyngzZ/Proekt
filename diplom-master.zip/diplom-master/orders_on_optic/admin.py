from django.contrib import admin
from .models import Optics_order 

admin.site.register(Optics_order)