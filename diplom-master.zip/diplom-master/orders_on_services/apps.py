from django.apps import AppConfig


class OrdersOnServicesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'orders_on_services'
