from django.contrib import admin
from .models import Services_order 

admin.site.register(Services_order)