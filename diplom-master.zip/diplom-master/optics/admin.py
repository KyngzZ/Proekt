from django.contrib import admin 
from .models import Optics 

admin.site.register(Optics)